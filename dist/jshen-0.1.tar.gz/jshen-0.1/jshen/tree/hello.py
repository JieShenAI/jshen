# _*_coding     : UTF_8_*_
# Author        :Jie Shen
# CreatTime     :2022/1/25 13:10

def hello():
    print("com.jshen.hello")
    print("see you later")
