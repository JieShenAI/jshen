# jshen
Tools
# 参考资料
setup.py:
1. https://www.cnblogs.com/maociping/p/6633948.html 
2. https://blog.csdn.net/coolcooljob/article/details/80082907
3. https://blog.csdn.net/weixin_43964444/article/details/108414571

python setup.py build
python setup.py sdist
python setup.py install
